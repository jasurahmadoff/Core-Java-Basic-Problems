package tools;

public class Methods {

    public static String lazimsizBosluqlariSil(String cumle) {

        // Gonderilmish cumleden butun lazimsiz boshluqlari silen kod
        // "   salam,    necesen? " => "salam, necesen?"
        String[] words = cumle.split("\\s+");

        String str = "";

        for (String word : words) {
            str += word + " ";
        }
        return str.trim();
    }

    public static String toogleWord(String s) {

        // Ele bir method yazin ki, boyuk herfler kicikle, kicik herfler boyukle evez olunsun
        String word = "";

        for (int i = 0; i < s.length(); i++) {

            if ((int) s.charAt(i) >= 65 && (int) s.charAt(i) <= 90) { // boyuk herf
                word += (char) ((int) s.charAt(i) + 32);
            } else if ((int) s.charAt(i) >= 97 && (int) s.charAt(i) <= 122) { // kicik herf
                word += (char) ((int) s.charAt(i) - 32);
            } else {
                word += "*";
            }
        }
        return word;
    }

    public static String maxLength(String a, String b) {

        // 2 soz daxil edilir uzunlugu boyuk olan String geriye return edilir.
        String max;

        if (a.length() >= b.length()) {
            max = a;
        } else {
            max = b;
        }
        return max;
    }

    public static void araligiChapEt(String a, int begin, int end) {

        // Methoda String a, int begin, int end daxil edilir.
        // a-nin begin ve end arasini alt-alta chap edir.
        for (int i = begin; i < end; i++) {
            System.out.println(a.charAt(i));
        }
    }

    public static boolean isIncluded(String a, String b, String c) {

        // Method 3 String qebul edir. String a, String b, String c. 
        // a ve b-nin ichinde c varsa, onda true eks halda false
        return a.contains(c) && b.contains(c);
    }

    public static String concatStrings(String word, char letter, int count) {

        // Method String s, char c, int count qebul edir. 
        // Stringi count qeder c ile birleshdirir ve geriye return edir
        for (int i = 1; i <= count; i++) {
            word += letter;
        }
        return word;
    }

    public static boolean stringIsEqual(String a, String b) {

        // Method 2 String qebul edir ve onlarin beraber olub-olmadigini 
        // return edir true ve ya false
        if (a.length() != b.length()) {
            return false;
        }
        for (int i = 0; i < a.length(); i++) {

            if (a.charAt(i) != b.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    public static char findChar(String soz, int index) {
        // Sozun verilmis index-inde olan simvolunu qaytaran method yazin
        return soz.charAt(index);
    }

    public static boolean isIncreased(int a, int b, int c, int d) {

        // Methoda 4 reqem daxil edilir: a,b,c,d eger ededler artan ardicilliqla daxil edilibse 
        // geriye true qaytarsin eks halda false
        int arr[] = {a, b, c, d};

        for (int i = 0; i < arr.length; i++) {

            for (int j = i + 1; j < arr.length; j++) {

                if (arr[i] > arr[j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean checkEquality(int a, int b, int c, int d) {

        // Methoda 4 reqem daxil edilir eger bu reqemlerden her hansisa 
        // 2-si bir birine beraberdirse geriye true qaytarsin
        int arr[] = {a, b, c, d};

        for (int i = 0; i < arr.length; i++) {

            for (int j = i + 1; j < arr.length; j++) {

                if (arr[i] == arr[j]) {
                    return true;
                }
            }
        }
        return false;
    }

    public static byte compare(int n) {

        // Eger menfidirse method geriye -1 qaytarsin, 0-dirsa 0, musbetdirse +1 qaytarsin.
        if (n > 0) {
            return 1;
        } else if (n == 0) {
            return 0;
        } else {
            return -1;
        }
    }

    public static void power(int a, int b, int c) {

        // a-dan b-ye qeder butun ededleri c qeder quvvete yukseldir
        for (int i = a; i <= b; i++) {
            System.out.println(i + " ^ " + c + " = " + (int) Math.pow(i, c));
        }
    }

    public static void chapEt(int a, char c, boolean altAlta) {

        // a qeder c simvolunu chap etsin. altAlta dəyişəni true-dursa altAlta 
        // eks halda yan yana chap etsin
        for (int i = 1; i <= a; i++) {
            if (altAlta) {
                System.out.println(c);
            } else {
                System.out.print(c);
            }
        }
        System.out.println();
    }

    public static boolean checkReverse(int n) {

        // Daxil edilen reqemin tersi ile duzunun eyni olub-olmadigini 
        // teyin eden method yazin
        int rev = 0;
        int num = n;
        while (num > 0) {
            rev = (rev * 10) + (num % 10);
            num /= 10;
        }
        return rev == n;
    }

    public static boolean checkStrings(String s) {

        // Verilen string-in tersi ile duzunun bir-birine beraber olub-olmadigini yoxla
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != s.charAt((s.length() - 1) - i)) {
                return false;
            }
        }
        return true;
    }

    public static void findFactorial(int n) {
        int fact = factorial(n);
        System.out.println(n + "! = " + fact);
    }

    private static int factorial(int n) {

        if (n == 0) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }

    public static void digitCount(int n) {

        int dig = (int) Math.log10(n) + 1;
        System.out.println("Reqemlerin sayi: " + dig);
    }

    public static void exchange(int a, int b) {

        // 3-cu deyishenden istifade etmeden 2 deyishenin yerini deyishmek
        System.out.println("Before: a = " + a + "\tb = " + b);
        a = a + b;
        b = a - b;
        a = a - b;
        System.out.println("After: a = " + a + "\tb = " + b);
    }

    public static void sumOfDigits(int n) {

        // Verilmish ededin butun reqemleri cemi
        int sum = 0;
        while (n > 0) {
            sum += n % 10;
            n /= 10;
        }
        System.out.print("Reqemlerin cemi: " + sum + "\n");
    }

    public static void primeNumbers(int n) {

        // 1-den verilmis edede qeder sade ededleri chap edir
        boolean flag;

        System.out.print("Sade ededler: ");
        for (int i = 1; i <= n; i++) {

            flag = true;

            for (int j = 2; j <= i / 2; j++) {

                if (i % j == 0) {
                    flag = false;
                    break;
                }
            }

            if (flag) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    public static void divideBy2(int n) {

        System.out.print("Ikiye bolunen ededler: ");
        for (int i = 0; i <= n; i++) {

            if (i % 2 == 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    public static void sozleIfadeEt(int n) {

        // Yazilmis reqemi soze cevirir. mes: 125: Yuz iyirmi bes
        int dig, rev = 0;
        String s = "";

        while (n > 0) {
            rev = (rev * 10) + (n % 10);
            n /= 10;
        }

        while (rev > 0) {

            dig = (int) Math.log10(rev) + 1;

            switch (dig) {

                case 1:
                    switch (rev % 10) {
                        case 1:
                            s += "Bir ";
                            break;
                        case 2:
                            s += "Iki ";
                            break;
                        case 3:
                            s += "Uc ";
                            break;
                        case 4:
                            s += "Dord ";
                            break;
                        case 5:
                            s += "Bes ";
                            break;
                        case 6:
                            s += "Alti ";
                            break;
                        case 7:
                            s += "Yeddi ";
                            break;
                        case 8:
                            s += "Sekkiz ";
                            break;
                        case 9:
                            s += "Doqquz ";
                            break;
                    }
                    break;

                case 2:

                    switch (rev % 10) {
                        case 1:
                            s += "On ";
                            break;
                        case 2:
                            s += "Iyirmi ";
                            break;
                        case 3:
                            s += "Otuz ";
                            break;
                        case 4:
                            s += "Qirx ";
                            break;
                        case 5:
                            s += "Elli ";
                            break;
                        case 6:
                            s += "Altmis ";
                            break;
                        case 7:
                            s += "Yetmis ";
                            break;
                        case 8:
                            s += "Seksen ";
                            break;
                        case 9:
                            s += "Doxsan ";
                            break;
                    }
                    break;

                case 3:

                    switch (rev % 10) {
                        case 1:
                            s += "Yuz ";
                            break;
                        case 2:
                            s += "Iki Yuz ";
                            break;
                        case 3:
                            s += "Uc Yuz ";
                            break;
                        case 4:
                            s += "Dord Yuz ";
                            break;
                        case 5:
                            s += "Bes Yuz ";
                            break;
                        case 6:
                            s += "Alti Yuz ";
                            break;
                        case 7:
                            s += "Yeddi Yuz ";
                            break;
                        case 8:
                            s += "Sekkiz Yuz ";
                            break;
                        case 9:
                            s += "Doqquz Yuz ";
                            break;
                    }
                    break;

                case 4:

                    switch (rev % 10) {
                        case 1:
                            s += "Min ";
                            break;
                        case 2:
                            s += "Iki Min ";
                            break;
                        case 3:
                            s += "Uc Min ";
                            break;
                        case 4:
                            s += "Dord Min ";
                            break;
                        case 5:
                            s += "Bes Min ";
                            break;
                        case 6:
                            s += "Alti Min ";
                            break;
                        case 7:
                            s += "Yeddi Min ";
                            break;
                        case 8:
                            s += "Sekkiz Min ";
                            break;
                        case 9:
                            s += "Doqquz Min ";
                            break;
                    }
                    break;
            }

            rev /= 10;
        }

        System.out.println((s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase()).trim());
    }
}