package core;

import tools.Methods;

public class Main {

    public static void main(String[] args) {

        // Lazim olan methoda parametrler gondererek istifade ede bilersiniz.
        // Meselen: 
        
        Methods.sozleIfadeEt(1918); // 1918 => Min doqquz yuz on sekkiz

        String cumle = "  Azerbaycan     respublikasi  demokratik      dovletdir.   ";
        System.out.println(Methods.lazimsizBosluqlariSil(cumle));
    }
}